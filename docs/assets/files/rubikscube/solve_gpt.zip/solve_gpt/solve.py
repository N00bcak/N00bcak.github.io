from __future__ import annotations

import argparse
import json
import shlex
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

try:
    import _dist_path  # noqa: F401
except ModuleNotFoundError:  # pragma: no cover - package import path
    from . import _dist_path  # type: ignore # noqa: F401
from rubikscube.core import (
    AXIS_INDEX,
    FACE_COLORS,
    CubeState,
    apply_move,
    apply_moves,
    invert_move,
)
from rubikscube.render import (
    RecordingUnavailable,
    StickerPolygon,
    _HIDDEN_STICKER_COLOR,
    _frame_count_for_duration,
    _rotate_point,
    _rotation_spec,
    _sticker_center,
    _animated_move_frames,
    build_sticker_polygons,
    can_record_mp4,
    CubeRenderer,
)
try:
    from client import ChallengeClient, ChallengeResponse, code_to_observation
    from group_theory.solver import SolverPlan, solve_components_with_observer
except ModuleNotFoundError:  # pragma: no cover - package import path
    from .client import ChallengeClient, ChallengeResponse, code_to_observation
    from .group_theory.solver import SolverPlan, solve_components_with_observer


@dataclass(frozen=True, slots=True)
class CubeRunStats:
    cube_index: int
    initial_code: int
    initial_observation: dict[str, bool]
    solution_moves: tuple[str, ...]
    observation_codes: tuple[int, ...]
    moves: int
    total_turns: int
    round_trips: int

    @property
    def solution_text(self) -> str:
        return " ".join(self.solution_moves)


def default_challenge_command() -> list[str]:
    return [sys.executable, "-u", "-m", "server.cli.app"]


class GroupTheoryCliSolver:
    def __init__(
        self,
        client: ChallengeClient,
        *,
        plan: SolverPlan | None = None,
        verbose: bool = False,
    ) -> None:
        self.client = client
        self.plan = plan
        self.verbose = verbose

    def run(self) -> tuple[CubeRunStats, ...]:
        response = self.client.start()
        if response.state_code is None:
            raise RuntimeError("Challenge did not provide an initial STATE line.")

        stats: list[CubeRunStats] = []
        cube_index = self._cube_index(response) or 1
        state_code = response.state_code

        while True:
            last_response = response
            initial_code = state_code
            initial_observation = code_to_observation(initial_code)
            observation_codes_list: list[int] = []

            def step(move: str) -> dict[str, bool]:
                nonlocal last_response
                last_response = self.client.apply_move(move)
                if last_response.failed:
                    raise RuntimeError("Challenge failed while applying solver moves.")
                if last_response.solved:
                    observation_codes_list.append(63)
                    return code_to_observation(63)
                if last_response.trace_codes:
                    observation_code = last_response.trace_codes[-1]
                elif last_response.state_code is not None:
                    observation_code = last_response.state_code
                else:
                    raise RuntimeError("Challenge move response did not include observation data.")
                observation_codes_list.append(observation_code)
                return code_to_observation(observation_code)

            moves = solve_components_with_observer(
                code_to_observation(state_code),
                step,
                plan=self.plan,
            )
            observation_codes = tuple(observation_codes_list)
            if not last_response.solved:
                raise RuntimeError("Solver plan ended without a SOLVED response from the challenge.")

            stats.append(
                CubeRunStats(
                    cube_index=cube_index,
                    initial_code=initial_code,
                    initial_observation=initial_observation,
                    solution_moves=moves,
                    observation_codes=tuple(observation_codes),
                    moves=len(moves),
                    total_turns=last_response.move_count if last_response.move_count is not None else len(moves),
                    round_trips=self.client.round_trips,
                )
            )
            if self.verbose:
                print(
                    f"[group] cube={cube_index} moves={len(moves)} "
                    f"turns={stats[-1].total_turns} round_trips={self.client.round_trips}",
                    file=sys.stderr,
                )

            if last_response.session_complete or last_response.final_average is not None:
                return tuple(stats)
            if last_response.state_code is None:
                last_response = self.client.run_command("state")
                if last_response.state_code is None:
                    raise RuntimeError("Challenge did not provide the next cube STATE line.")
            response = last_response
            state_code = response.state_code
            cube_index = self._cube_index(response) or cube_index + 1

    @staticmethod
    def _cube_index(response: ChallengeResponse) -> int | None:
        for line in response.lines:
            if line.startswith("CUBE "):
                fields = dict(field.split("=", 1) for field in line.split()[1:] if "=" in field)
                index = fields.get("index")
                if index is not None:
                    return int(index)
        return None


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Challenger-side solver client for the masked 2x2x2 CTF service")
    parser.add_argument("--challenge-command", help="Alternate challenge command to spawn instead of the local app.")
    parser.add_argument("--team-token", help="Team token to send if the challenge server requests one.")
    parser.add_argument(
        "--strategy",
        choices=("group",),
        default="group",
        help="Solver strategy to run.",
    )
    parser.add_argument("--cache-dir", type=Path, help="Accepted for compatibility; the group strategy builds its plan in memory.")
    parser.add_argument("--moves-out", type=Path, help="Write the solved move sequence to this file.")
    parser.add_argument("--video-out", type=Path, help="Render a public solved-mask MP4 of the solve.")
    parser.add_argument("--full-video-out", type=Path, help="Render a local full-state MP4 of the solve.")
    parser.add_argument("--video-fps", type=int, default=12, help="Frames per second for --video-out.")
    parser.add_argument("--move-duration", type=float, default=0.2, help="Seconds per move for rendered videos.")
    parser.add_argument(
        "--video-sample-every",
        type=int,
        default=1,
        help="Render every Nth move in --video-out while keeping the final solved frame.",
    )
    parser.add_argument("--verbose", action="store_true", help="Print solver progress to stderr.")
    args = parser.parse_args(argv)

    del args.cache_dir
    command = shlex.split(args.challenge_command) if args.challenge_command else default_challenge_command()
    client = ChallengeClient(command, team_token=args.team_token)
    solver = GroupTheoryCliSolver(client, verbose=args.verbose)
    try:
        stats = solver.run()
    finally:
        client.close()

    for cube in stats:
        print(
            f"SOLVER2_INITIAL cube={cube.cube_index} code={cube.initial_code} "
            f"masked={json.dumps(cube.initial_observation, sort_keys=True)}"
        )
        print(
            f"SOLVER2_MOVES cube={cube.cube_index} count={cube.moves} "
            f"sequence={cube.solution_text}"
        )
        print(
            f"SOLVER2 cube={cube.cube_index} moves={cube.moves} "
            f"turns={cube.total_turns} round_trips={cube.round_trips}"
        )
    if args.moves_out is not None:
        _write_moves_file(args.moves_out, stats)
    if args.video_out is not None:
        _record_public_mask_video(
            args.video_out,
            stats,
            move_duration=args.move_duration,
            fps=args.video_fps,
            sample_every=args.video_sample_every,
        )
    if args.full_video_out is not None:
        _record_full_state_video(
            args.full_video_out,
            stats,
            move_duration=args.move_duration,
            fps=args.video_fps,
            sample_every=args.video_sample_every,
        )
    return 0


def _write_moves_file(path: Path, stats: Sequence[CubeRunStats]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if len(stats) == 1:
        path.write_text(stats[0].solution_text + "\n")
        return
    path.write_text("".join(f"cube {cube.cube_index}: {cube.solution_text}\n" for cube in stats))


def _record_public_mask_video(
    path: Path,
    stats: Sequence[CubeRunStats],
    *,
    move_duration: float,
    fps: int,
    sample_every: int = 1,
) -> None:
    if not can_record_mp4():
        raise RecordingUnavailable("MP4 export requires ffmpeg to be installed and visible to Matplotlib.")
    if sample_every <= 0:
        raise ValueError("sample_every must be positive.")

    from matplotlib import animation

    path.parent.mkdir(parents=True, exist_ok=True)
    renderer = CubeRenderer(render_mode="solved-mask")
    writer = animation.FFMpegWriter(fps=fps, bitrate=1200, extra_args=["-pix_fmt", "yuv420p"])

    with writer.saving(renderer.figure, str(path), dpi=100):
        for cube in stats:
            renderer.draw_snapshot(_observation_from_code(cube.initial_code))
            writer.grab_frame()
            current_code = cube.initial_code
            frame_count = _frame_count_for_duration(move_duration, fps=fps)
            move_pairs = tuple(zip(cube.solution_moves, cube.observation_codes, strict=True))
            for index, (move, next_code) in enumerate(move_pairs, start=1):
                if index % sample_every != 0 and next_code != 63 and index != len(move_pairs):
                    current_code = next_code
                    continue
                for polygons in _animated_public_mask_frames(current_code, move, next_code, frame_count=frame_count):
                    renderer._render_polygons(polygons, label=f"group public move={move}")
                    writer.grab_frame()
                current_code = next_code
            renderer.draw_snapshot(_observation_from_code(current_code))
            writer.grab_frame()


def _record_full_state_video(
    path: Path,
    stats: Sequence[CubeRunStats],
    *,
    move_duration: float,
    fps: int,
    sample_every: int = 1,
) -> None:
    if not can_record_mp4():
        raise RecordingUnavailable("MP4 export requires ffmpeg to be installed and visible to Matplotlib.")
    if sample_every <= 0:
        raise ValueError("sample_every must be positive.")

    from matplotlib import animation

    path.parent.mkdir(parents=True, exist_ok=True)
    renderer = CubeRenderer(render_mode="normal")
    writer = animation.FFMpegWriter(fps=fps, bitrate=1200, extra_args=["-pix_fmt", "yuv420p"])

    with writer.saving(renderer.figure, str(path), dpi=100):
        for cube in stats:
            current_state = _initial_state_from_solution(cube.solution_moves)
            renderer.draw_state(current_state, render_mode="normal")
            writer.grab_frame()
            frame_count = _frame_count_for_duration(move_duration, fps=fps)
            for index, move in enumerate(cube.solution_moves, start=1):
                next_state = apply_move(current_state, move)
                if index % sample_every == 0 or index == len(cube.solution_moves) or next_state == CubeState.solved():
                    for polygons in _animated_move_frames(
                        current_state,
                        move,
                        next_state,
                        render_mode="normal",
                        frame_count=frame_count,
                    ):
                        renderer._render_polygons(polygons, label=f"group full move={move}")
                        writer.grab_frame()
                current_state = next_state
            renderer.draw_state(current_state, render_mode="normal")
            writer.grab_frame()


def _initial_state_from_solution(solution_moves: Sequence[str]) -> CubeState:
    inverse_solution = tuple(invert_move(move) for move in reversed(solution_moves))
    return apply_moves(CubeState.solved(), inverse_solution)


def _observation_from_code(code: int) -> dict[str, tuple[tuple[str, str], tuple[str, str]]]:
    observation: dict[str, tuple[tuple[str, str], tuple[str, str]]] = {}
    for bit, (face, color) in enumerate(FACE_COLORS.items()):
        sticker = color if code & (1 << bit) else _HIDDEN_STICKER_COLOR
        observation[face] = ((sticker, sticker), (sticker, sticker))
    return observation


def _animated_public_mask_frames(
    before_code: int,
    move: str,
    after_code: int,
    *,
    frame_count: int,
) -> tuple[tuple[StickerPolygon, ...], ...]:
    del before_code  # Public solved-mask animation uses target visibility from the first frame.
    stickers = build_sticker_polygons(_observation_from_code(after_code))
    axis_name, layer_sign, rotation = _rotation_spec(move)
    affected = {
        index
        for index, sticker in enumerate(stickers)
        if _sticker_center(sticker.vertices)[AXIS_INDEX[axis_name]] * layer_sign > 0.2
    }
    frames: list[tuple[StickerPolygon, ...]] = []
    for frame_index in range(frame_count):
        angle = rotation * 90.0 * frame_index / (frame_count - 1)
        animated: list[StickerPolygon] = []
        for index, sticker in enumerate(stickers):
            vertices = sticker.vertices
            if index in affected:
                vertices = tuple(_rotate_point(vertex, axis_name, angle) for vertex in vertices)
            animated.append(
                StickerPolygon(
                    face=sticker.face,
                    row=sticker.row,
                    col=sticker.col,
                    color=sticker.color,
                    vertices=vertices,
                )
            )
        frames.append(tuple(animated))
    return tuple(frames)


if __name__ == "__main__":
    raise SystemExit(main())
